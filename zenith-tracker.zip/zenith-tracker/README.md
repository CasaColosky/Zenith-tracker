# Zenith Tracker

A phone-first, camera-based sports tracker. Point the camera at a field, tap a
detected player (or the ball), and it follows them automatically while reading
out **speed, position, a movement trail, a heatmap, and per-play peak speeds**.

Runs entirely on-device. One static HTML file, no backend, no build step.

---

## What it does

- **AI detection** — TensorFlow.js + COCO-SSD (MobileNet-lite). Detects every
  player/ball in frame; you tap the one to follow and it auto-tracks across
  frames. No color tuning.
- **Live telemetry** — speed (km/h / mph / m/s), session max, distance, time,
  and frame position.
- **Trail + heatmap** — fading movement path and a toggleable occupancy heatmap.
- **Per-play capture** — Rec → run the play → Stop. Logs peak speed, distance,
  duration, and average, saved locally and shown in the Log panel.

## How to use

1. Open the page on your phone (over **https** — camera requires a secure origin).
2. Tap **Start**. Allow camera. First load downloads the model (~6 MB), then it's cached.
3. Tap a detected player (or switch to **Ball**) to lock on.
4. Tap **Set Scale**, tap two points a known distance apart (court width, a 5 m
   line), enter the meters. *Speed is only real after this step.*
5. **Rec Play** to capture a segment; **Log** to review saved plays.

## Accuracy notes (read these)

- **Mount the phone or hold it still.** Speed is measured from motion in the
  frame — panning/walking corrupts it.
- **Calibration is planar.** Movement toward/away from the camera reads off due
  to perspective. Best with side-on framing.
- Detection runs every frame asynchronously; small/fast/occluded targets are the
  hard cases. The conf slider trades sensitivity for false positives.

## Run locally

```bash
# any static server works; python is easiest
cd zenith-tracker
python3 -m http.server 8080
# then open http://localhost:8080 on the same machine,
# or your phone via your LAN IP — but note: camera needs https,
# so for phone testing use a tunnel (e.g. cloudflared/ngrok) or deploy.
```

## Deploy

It's one static file, so it hosts anywhere. Pick based on whether you want the
**source** private:

### A. Public repo + GitHub Pages (free)
```bash
gh repo create zenith-tracker --public --source=. --remote=origin --push
gh api -X POST repos/:owner/zenith-tracker/pages -f source.branch=main -f source.path=/ 2>/dev/null || true
# Settings → Pages → Branch: main /(root). Live at:
# https://<you>.github.io/zenith-tracker/
```

### B. Private source, still free hosting — Cloudflare Pages or Netlify
GitHub Pages on a **private** repo needs a paid plan. To keep source private for
free, push private and deploy the static output elsewhere:
```bash
gh repo create zenith-tracker --private --source=. --remote=origin --push
# then connect the repo in Cloudflare Pages / Netlify (build command: none,
# output dir: /). Both serve from private repos on the free tier.
```

### C. Subfolder on an existing site
Drop `index.html` at e.g. `robcolosky.com/tracker/index.html` and link it. Done.

## Tech

- Vanilla HTML/CSS/JS, single file (`index.html`).
- `@tensorflow/tfjs@4.22.0` + `@tensorflow-models/coco-ssd@2.2.3` via jsDelivr CDN.
- Play log persisted in `localStorage` (per-device).

## Roadmap ideas

- CSV/JSON export of the play log.
- Multi-player simultaneous tracking + jersey-number OCR.
- Perspective correction (homography) for true field coordinates.
- Pose estimation for stride/cadence.
